import UIKit

var str = "esto es un string"
var int = 84
var double = 55.3
var arreglo = [1,2]
var diccionario = [Int:String]()

arreglo.append(3)
print(arreglo)

diccionario	= [1:"Lunes",2:"Martes",3:"Miercoles",4:"Jueves"]

//anadir mas elementos

diccionario[5]="Viernes"

print(diccionario)

//acceder a uun dato especifico
diccionario[2]


print(str)
print (double)
print(int)



